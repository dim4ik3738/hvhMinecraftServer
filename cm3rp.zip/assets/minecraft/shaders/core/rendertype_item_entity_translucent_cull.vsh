#version 150
#moj_import<minecraft:light.glsl>
#moj_import<minecraft:fog.glsl>
#moj_import<minecraft:dynamictransforms.glsl>
#moj_import<minecraft:projection.glsl>
#moj_import<minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in vec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;
out vec2 texCoord1;
out vec2 texCoord2;

#moj_import<_d230d9d2f9d8c488.glsl>
#moj_import<_42b917011983f397.glsl>

void main() {
    vec3 pos = Position;
    bool isGun = false;
    
    if (pos.y <= -2000.0) {
        isGun = true;
        int mode = int((pos.y + 2000.0) / -1000.0);
        pos.y += (mode * 1000) + 2500;
    }
    
    vec4 viewPos;
    
    if (isGun) {
        vec4 center = ModelViewMat * vec4(0.0, 0.0, 0.0, 1.0);
        
        vec3 right = vec3(1.0, 0.0, 0.0);
        vec3 up = vec3(0.0, 1.0, 0.0);
        vec3 forward = vec3(0.0, 0.0, 1.0);
        
        viewPos.xyz = center.xyz + right * pos.x + up * pos.y + forward * pos.z;
        viewPos.w = 1.0;
        
    } else {
        viewPos = ModelViewMat * vec4(pos, 1.0);
    }
    
    gl_Position = ProjMat * viewPos;
    
    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color) * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    texCoord1 = UV1;
    texCoord2 = UV2;
    
    if (isGun) {
        gl_Position.z *= 0.1;
    }
}